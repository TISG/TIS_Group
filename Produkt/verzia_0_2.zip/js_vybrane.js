


var okno;

(function () {

  okno = function () {
    RWindow.call (this, 30, 10, 600, 500, 'pen24.png');

    var self = this;

    this.change_cfg ({bgcolor:'rgb(164, 234, 164)', selcolor:'rgb(81, 218, 129)'});
    this.resizeable = true;
    this.dragable = true;
    this.lab.innerHTML = 'Vybrané slová';
    this.lab.style.textAlign = 'center';
    this.lab.style.marginLeft = '0px';


    self.con.innerHTML = '  <p><button id="cv">Cvičenia</button> <button id="help">Nápoveda</button> </p>  '
    cv = this.con.getElementById("cv");
    cv.addEventListener("click", cvicenia);
    help = this.con.getElementById("help");
    help.addEventListener("click", zobrazNapovedu);


    function cvicenia() {
      self.con.innerHTML = '   <p><button id="cv">Cvičenia</button> <button id="help">Nápoveda</button></p> \
      <h2>Vyber si cvičenie</h2>     \
      <p><button id="cv1">Cvičenie 1</button></p>  \
      <p><button id="cv2">Cvičenie 2</button></p>  \
      <p><button id="cv3">Cvičenie 3</button></p> '
    


      cv = self.con.getElementById("cv");
      cv.addEventListener("click", cvicenia);
      help = self.con.getElementById("help");
      help.addEventListener("click", zobrazNapovedu);
      cv1 = self.con.getElementById("cv1");
      cv1.addEventListener("click", cvicenie1);

      function cvicenie1() {
        console.log("Cvicenie 1");
        self.con.innerHTML = '    <div id="container">  \
        <h1>Quiz o vybraných slovách</h1>     \
        <p>Za neodpovedané otázky body nedostaneš!!</p>    \
        <div id="content">        \
          <img src="" id="otazka" height="200" width="250">    \
          <div id="moznosti"></div>    \
          <p><button id="submit"></button></p>   \
          <p id="skore"></p>  \
          </div>    \
        </div>  '
      
        content = self.con.getElementById("content");
        otazkaContainer = self.con.getElementById("otazka");
        moznostiContainer = self.con.getElementById("moznosti");
        skoreContainer = self.con.getElementById("skore");
        submitBtn = self.con.getElementById("submit");

        $jq.getScript('js_cvicenia.js', function() {
          console.log("podarilo sa");
        }); 
      }

    
      cv2 = self.con.getElementById("cv2");
      cv2.addEventListener("click", cvicenie2);

      function cvicenie2() {
        console.log("Cvicenie 2");
        self.con.innerHTML = '  <h1>Vybral si druhe cvicenie.</h1>   '
      
      }
    
      cv3 = self.con.getElementById("cv3");
      cv3.addEventListener("click", cvicenie3);

      function cvicenie3() {
        console.log("Cvicenie 3");
        self.con.innerHTML = '  <h1>Vybral si tretie cvicenie.</h1>   '
      
      }
    }
    function zobrazNapovedu() {
      self.con.innerHTML = '<p><button id="cv">Cvičenia</button> <button id="help">Nápoveda</button></p> \
      <h2>Nápoveda</h2> \
      <p>Toto je nápoveda. Tu sa dozvieš veci, ktoré nevieš.</p> '
      
      cv = self.con.getElementById("cv");
      cv.addEventListener("click", cvicenia);
      help = self.con.getElementById("help");
      help.addEventListener("click", zobrazNapovedu);
    }
  
    

   
   

    
     
      
     

    this.Bclose.style.visibility = 'visible';
    this.Bclose.addEventListener ('mousedown', function (e) {
      self.hide ();
      menu.Add (self.ico);
      e.stopPropagation ();
    });


    this.ico = Asset.image ('obrazky/pen24.png');
    menu.Add (this.ico);
    this.ico.addEventListener ('mousedown', function (e) {
      self.show ();
      menu.Rem (self.ico);
      e.stopPropagation ();
    });
    
    this.ico2 = Asset.image ('obrazky/pen24.png');
    this.ico2.addEventListener ('mousedown', function (e) {
      self.show ();
      menu.Rem (self.ico);
      e.stopPropagation ();
    });
    
  };

  (function (){
    function Tmp () {};
    Tmp.prototype = RWindow.prototype;
    okno.prototype = new Tmp ();
  })();

})();