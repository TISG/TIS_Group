
var okno;

(function () {

  okno = function () {
    RWindow.call (this, 260, 35, 650, 590, 'pen24.png');

    var self = this;

    this.change_cfg ({bgcolor:'rgb(164, 234, 164)', selcolor:'rgb(81, 218, 129)'});
    this.resizeable = true;
    this.dragable = true;
    this.lab.innerHTML = 'Vybrané slová';
    this.lab.style.textAlign = 'center';
    this.lab.style.marginLeft = '0px';
    //Adrian
    // zobrazi buttony hlavneho menu pri prvotnom vytvoreni okna
    self.con.innerHTML = '<p><button id="cv">Cvičenia</button> <button id="vybrane">Vybrané slová</button>   \
       <button id="help">Nápoveda</button> </p> '
    cv = this.con.getElementById("cv");
    cv.addEventListener("click", zobrazCvicenia);
    help = this.con.getElementById("help");
    help.addEventListener("click", zobrazNapovedu);
    vybraneSlova = self.con.getElementById("vybrane");
    vybraneSlova.addEventListener("click", zobrazVybraneSlova);

    // zobrazi buttony cviceni
    function zobrazCvicenia() {
      self.con.innerHTML = '   <p><button id="cv">Cvičenia</button> <button id="vybrane">Vybrané slová</button>   \
       <button id="help">Nápoveda</button> </p>  \
      <h2>Vyber si cvičenie</h2>     \
      <p><button id="cv1">Cvičenie 1</button></p>  \
      <p><button id="cv2">Cvičenie 2</button></p>  \
      <p><button id="cv3">Cvičenie 3</button></p> '
    

      cv = self.con.getElementById("cv");
      cv.addEventListener("click", zobrazCvicenia);
      
      help = self.con.getElementById("help");
      help.addEventListener("click", zobrazNapovedu);
      
      vybraneSlova = self.con.getElementById("vybrane");
      vybraneSlova.addEventListener("click", zobrazVybraneSlova);
      
      cv1 = self.con.getElementById("cv1");
      cv1.addEventListener("click", cvicenie1);
      
      cv2 = self.con.getElementById("cv2");
      cv2.addEventListener("click", cvicenie2);
      
      cv3 = self.con.getElementById("cv3");
      cv3.addEventListener("click", cvicenie3);
      
      

      function cvicenie1() {
        console.log("Cvicenie 1");
        self.con.innerHTML = '<p><button id="cv">Cvičenia</button> <button id="vybrane">Vybrané slová</button>   \
       <button id="help">Nápoveda</button> </p>  \
            <div id="container">  \
        <p><br>Z dvojice vyber slovo, ktoré je podľa teba správne.</p>    \
        <div id="content">        \
          <img src="" id="otazka" height="200" width="250">    \
          <div id="moznosti"></div>    \
          <p><button id="submit"></button></p>   \
          <p id="skore"></p>  \
          </div>    \
        </div>  '
      
        cv = self.con.getElementById("cv");
        cv.addEventListener("click", zobrazCvicenia);
        help = self.con.getElementById("help");
        help.addEventListener("click", zobrazNapovedu);
        vybraneSlova = self.con.getElementById("vybrane");
        vybraneSlova.addEventListener("click", zobrazVybraneSlova);
        
        content = self.con.getElementById("content");
        otazkaContainer = self.con.getElementById("otazka");
        moznostiContainer = self.con.getElementById("moznosti");
        skoreContainer = self.con.getElementById("skore");
        submitBtn = self.con.getElementById("submit");

        $jq.getScript('js_cvicenia.js', function() {
          console.log("Cvicenie 1 skript nacitany");
        }); 
      }

    

      //Martin
      function cvicenie2() {
        console.log("Cvicenie 2");
        self.con.innerHTML = '<p><button id="cv">Cvičenia</button> <button id="help">Nápoveda</button></p> \
            <div id="container">  \
        <h2>Cvičenie 2</h2>     \
        <p>Vyber slovo, ktoré nie je vybrané.</p>    \
        <div id="content">        \
          <table id="zobrazeneMoznosti"></table>    \
          <p><button id="submit"></button></p>   \
          <p id="skore"></p>  \
          </div>    \
        </div>  '
          
        cv = self.con.getElementById("cv");
        cv.addEventListener("click", zobrazCvicenia);
        help = self.con.getElementById("help");
        help.addEventListener("click", zobrazNapovedu);
        
        content = self.con.getElementById("content");
        moznostiContainer = self.con.getElementById("zobrazeneMoznosti");
        skoreContainer = self.con.getElementById("skore");
        submitBtn = self.con.getElementById("submit");

        $jq.getScript('js_cvicenia2.js', function() {
          console.log("Cvicenie 2 skript nacitany");
        });
      }
      
      //Peter
  		function cvicenie3() {
  		  console.log("Cvicenie 3");
        self.con.innerHTML = '<p><button id="cv">Cvičenia</button> <button id="vybrane">Vybrané slová</button>   \
        <button id="help">Nápoveda</button> </p>  \
  		  <h2>Vyber si druh vybraných slov</h2>     \
  		  <p><button id="pexeso_b">po B</button></p>  \
  		  <p><button id="pexeso_m">po M</button></p>  \
  		  <p><button id="pexeso_p">po P</button></p>  \
  		  <p><button id="pexeso_r">po R</button></p>  \
  		  <p><button id="pexeso_s">po S</button></p>  \
  		  <p><button id="pexeso_v">po V</button></p>  \
  		  <p><button id="pexeso_z">po Z</button></p> '
  		
  
  		  cv = self.con.getElementById("cv");
  		  cv.addEventListener("click", zobrazCvicenia);
  		  help = self.con.getElementById("help");
  		  help.addEventListener("click", zobrazNapovedu);
        vybraneSlova = self.con.getElementById("vybrane");
        vybraneSlova.addEventListener("click", zobrazVybraneSlova);
  		  b = self.con.getElementById("pexeso_b");
  		  b.addEventListener("click", vybraneSlova_B);
  		  m = self.con.getElementById("pexeso_m");
  		  m.addEventListener("click", vybraneSlova_M);
  		  p = self.con.getElementById("pexeso_p");
  		  p.addEventListener("click", vybraneSlova_P);
  		  r = self.con.getElementById("pexeso_r");
  		  r.addEventListener("click", vybraneSlova_R);
  		  s = self.con.getElementById("pexeso_s");
  		  s.addEventListener("click", vybraneSlova_S);
  		  v = self.con.getElementById("pexeso_v");
  		  v.addEventListener("click", vybraneSlova_V);
  		  z = self.con.getElementById("pexeso_z");
  		  z.addEventListener("click", vybraneSlova_Z);
  		  
  
  		  function vybraneSlova_B() {
          self.con.innerHTML = '<p><button id="cv">Cvičenia</button> <button id="vybrane">Vybrané slová</button>   \
          <button id="help">Nápoveda</button> </p>  \
    			<div id="memory_board"></div> \
    			'
    			
    			cv = self.con.getElementById("cv");
    			cv.addEventListener("click", zobrazCvicenia);
    			help = self.con.getElementById("help");
    			help.addEventListener("click", zobrazNapovedu);
          vybraneSlova = self.con.getElementById("vybrane");
          vybraneSlova.addEventListener("click", zobrazVybraneSlova);
    			
    			memory_board = self.con.getElementById("memory_board");
    			$jq.getScript('pexeso/js_pexeso_b.js', function() {
    				console.log("Pexeso skript nacitany");
    			}); 
  		  }
  		  
  		  function vybraneSlova_M() {
          self.con.innerHTML = '<p><button id="cv">Cvičenia</button> <button id="vybrane">Vybrané slová</button>   \
          <button id="help">Nápoveda</button> </p>  \
    			<div id="memory_board"></div> \
    			'
    			
    			cv = self.con.getElementById("cv");
    			cv.addEventListener("click", zobrazCvicenia);
    			help = self.con.getElementById("help");
    			help.addEventListener("click", zobrazNapovedu);
          vybraneSlova = self.con.getElementById("vybrane");
          vybraneSlova.addEventListener("click", zobrazVybraneSlova);
    			
    			memory_board = self.con.getElementById("memory_board");
    			$jq.getScript('pexeso/js_pexeso_m.js', function() {
    				console.log("Pexeso skript nacitany");
    			}); 
  		  }
  		  
  		  function vybraneSlova_P() {
          self.con.innerHTML = '<p><button id="cv">Cvičenia</button> <button id="vybrane">Vybrané slová</button>   \
          <button id="help">Nápoveda</button> </p>  \
    			<div id="memory_board"></div> \
    			'
    			
    			cv = self.con.getElementById("cv");
    			cv.addEventListener("click", zobrazCvicenia);
    			help = self.con.getElementById("help");
    			help.addEventListener("click", zobrazNapovedu);
          vybraneSlova = self.con.getElementById("vybrane");
          vybraneSlova.addEventListener("click", zobrazVybraneSlova);
    			
    			memory_board = self.con.getElementById("memory_board");
    			$jq.getScript('pexeso/js_pexeso_p.js', function() {
    				console.log("Pexeso skript nacitany");
    			}); 
  		  }
  		  
  		  function vybraneSlova_R() {
          self.con.innerHTML = '<p><button id="cv">Cvičenia</button> <button id="vybrane">Vybrané slová</button>   \
          <button id="help">Nápoveda</button> </p>  \
    			<div id="memory_board"></div> \
    			'
    			
    			cv = self.con.getElementById("cv");
    			cv.addEventListener("click", zobrazCvicenia);	
    			help = self.con.getElementById("help");
    			help.addEventListener("click", zobrazNapovedu);
          vybraneSlova = self.con.getElementById("vybrane");
          vybraneSlova.addEventListener("click", zobrazVybraneSlova);
    			
    			memory_board = self.con.getElementById("memory_board");
    			$jq.getScript('pexeso/js_pexeso_r.js', function() {
    				console.log("Pexeso skript nacitany");
    			}); 
  		  }
  		  
  		  function vybraneSlova_S() {
          self.con.innerHTML = '<p><button id="cv">Cvičenia</button> <button id="vybrane">Vybrané slová</button>   \
          <button id="help">Nápoveda</button> </p>  \
    			<div id="memory_board"></div> \
    			'
    			
    			cv = self.con.getElementById("cv");
    			cv.addEventListener("click", zobrazCvicenia);
    			help = self.con.getElementById("help");
    			help.addEventListener("click", zobrazNapovedu);
          vybraneSlova = self.con.getElementById("vybrane");
          vybraneSlova.addEventListener("click", zobrazVybraneSlova);
    			
    			memory_board = self.con.getElementById("memory_board");
    			$jq.getScript('pexeso/js_pexeso_s.js', function() {
    				console.log("Pexeso skript nacitany");
    			}); 
  		  }
  		  
  		  function vybraneSlova_V() {
          self.con.innerHTML = '<p><button id="cv">Cvičenia</button> <button id="vybrane">Vybrané slová</button>   \
          <button id="help">Nápoveda</button> </p>  \
    			<div id="memory_board"></div> \
    			'
    			
    			cv = self.con.getElementById("cv");
    			cv.addEventListener("click", zobrazCvicenia);	
    			help = self.con.getElementById("help");
    			help.addEventListener("click", zobrazNapovedu);
          vybraneSlova = self.con.getElementById("vybrane");
          vybraneSlova.addEventListener("click", zobrazVybraneSlova);
    			
    			memory_board = self.con.getElementById("memory_board");
    			$jq.getScript('pexeso/js_pexeso_v.js', function() {
    				console.log("Pexeso skript nacitany");
    			}); 
  		  }
  		  
  		  function vybraneSlova_Z() {
          self.con.innerHTML = '<p><button id="cv">Cvičenia</button> <button id="vybrane">Vybrané slová</button>   \
          <button id="help">Nápoveda</button> </p>  \
    			<div id="memory_board"></div> \
    			'
    			
    			cv = self.con.getElementById("cv");
    			cv.addEventListener("click", zobrazCvicenia);
    			help = self.con.getElementById("help");
    			help.addEventListener("click", zobrazNapovedu);
          vybraneSlova = self.con.getElementById("vybrane");
          vybraneSlova.addEventListener("click", zobrazVybraneSlova);
    			
    			memory_board = self.con.getElementById("memory_board");
    			$jq.getScript('pexeso/js_pexeso_z.js', function() {
    				console.log("Pexeso skript nacitany");
    			}); 
  		  }
  	  }
	  }
    //Adrian
    function zobrazVybraneSlova() {
      self.con.innerHTML = '<p><button id="cv">Cvičenia</button> <button id="vybrane">Vybrané slová</button>   \
       <button id="help">Nápoveda</button> </p>  \
      <h2>Vybrané slová</h2> \
      <p><button id="poB">po B</button> <button id="poM">po M</button> <button id="poP">po P</button>  \
      <button id="poR">po R</button> <button id="poS">po S</button> <button id="poV">po V</button>  \
      <button id="poZ">po Z</button> <button id="poL">po L</button> '

      cv = self.con.getElementById("cv");
      cv.addEventListener("click", zobrazCvicenia);
      help = self.con.getElementById("help");
      help.addEventListener("click", zobrazNapovedu);
      vybraneSlova = self.con.getElementById("vybrane");
      vybraneSlova.addEventListener("click", zobrazVybraneSlova);
      vybraneSlovaPoB = self.con.getElementById("poB");
      vybraneSlovaPoB.addEventListener("click", poB);
      vybraneSlovaPoM = self.con.getElementById("poM");
      vybraneSlovaPoM.addEventListener("click", poM);
      vybraneSlovaPoP = self.con.getElementById("poP");
      vybraneSlovaPoP.addEventListener("click", poP);
      vybraneSlovaPoR = self.con.getElementById("poR");
      vybraneSlovaPoR.addEventListener("click", poR);
      vybraneSlovaPoS = self.con.getElementById("poS");
      vybraneSlovaPoS.addEventListener("click", poS);
      vybraneSlovaPoV = self.con.getElementById("poV");
      vybraneSlovaPoV.addEventListener("click", poV);
      vybraneSlovaPoZ = self.con.getElementById("poZ");
      vybraneSlovaPoZ.addEventListener("click", poZ);  
      vybraneSlovaPoL = self.con.getElementById("poL");
      vybraneSlovaPoL.addEventListener("click", poL);
      
      function poB() {
        self.con.innerHTML = '<p><button id="cv">Cvičenia</button> <button id="vybrane">Vybrané slová</button>   \
        <button id="help">Nápoveda</button> </p>  \
        <h2>Vybrané slová</h2> \
        <p><button id="poB">po B</button> <button id="poM">po M</button> <button id="poP">po P</button>  \
        <button id="poR">po R</button> <button id="poS">po S</button> <button id="poV">po V</button>  \
        <button id="poZ">po Z</button> <button id="poL">po L</button> \
        <p>by, aby, byľ, bystrý, Bystrica, Bytča, byť (existovať),    \
        nábytok, bývať, byt, bydlisko, príbytok, dobytok, kobyla, obyčaj, býk,      \
        bylina, bydlo (bývanie), dobyť (zmocniť sa), odbyt, byvol, bytosť, bývalý,   \
        úbytok, prebytok, zbytočný</p>   '
      
        cv = self.con.getElementById("cv");
        cv.addEventListener("click", zobrazCvicenia);
        help = self.con.getElementById("help");
        help.addEventListener("click", zobrazNapovedu);
        vybraneSlova = self.con.getElementById("vybrane");
        vybraneSlova.addEventListener("click", zobrazVybraneSlova);
        vybraneSlovaPoB = self.con.getElementById("poB");
        vybraneSlovaPoB.addEventListener("click", poB);
        vybraneSlovaPoM = self.con.getElementById("poM");
        vybraneSlovaPoM.addEventListener("click", poM);
        vybraneSlovaPoP = self.con.getElementById("poP");
        vybraneSlovaPoP.addEventListener("click", poP);
        vybraneSlovaPoR = self.con.getElementById("poR");
        vybraneSlovaPoR.addEventListener("click", poR);
        vybraneSlovaPoS = self.con.getElementById("poS");
        vybraneSlovaPoS.addEventListener("click", poS);
        vybraneSlovaPoV = self.con.getElementById("poV");
        vybraneSlovaPoV.addEventListener("click", poV);
        vybraneSlovaPoZ = self.con.getElementById("poZ");
        vybraneSlovaPoZ.addEventListener("click", poZ);  
        vybraneSlovaPoL = self.con.getElementById("poL");
        vybraneSlovaPoL.addEventListener("click", poL);          
      }
      
      function poM() {
        self.con.innerHTML = '<p><button id="cv">Cvičenia</button> <button id="vybrane">Vybrané slová</button>   \
        <button id="help">Nápoveda</button> </p>  \
        <h2>Vybrané slová</h2> \
        <p><button id="poB">po B</button> <button id="poM">po M</button> <button id="poP">po P</button>  \
        <button id="poR">po R</button> <button id="poS">po S</button> <button id="poV">po V</button>  \
        <button id="poZ">po Z</button> <button id="poL">po L</button> \
        <p>my, mykať sa, mýliť sa, myslieť, myšlienka,  \
        myseľ, umývať sa, mydlo, myš, šmýkať sa, hmyz, žmýkať, priemysel, Myjava,   \
        mýto, mys, zamykať, pomykov, hmýriť sa, šmyk, priesmyk, omyl, zmysel, pomyje</p>   '
      
        cv = self.con.getElementById("cv");
        cv.addEventListener("click", zobrazCvicenia);
        help = self.con.getElementById("help");
        help.addEventListener("click", zobrazNapovedu);
        vybraneSlova = self.con.getElementById("vybrane");
        vybraneSlova.addEventListener("click", zobrazVybraneSlova);
        vybraneSlovaPoB = self.con.getElementById("poB");
        vybraneSlovaPoB.addEventListener("click", poB);
        vybraneSlovaPoM = self.con.getElementById("poM");
        vybraneSlovaPoM.addEventListener("click", poM);
        vybraneSlovaPoP = self.con.getElementById("poP");
        vybraneSlovaPoP.addEventListener("click", poP);
        vybraneSlovaPoR = self.con.getElementById("poR");
        vybraneSlovaPoR.addEventListener("click", poR);
        vybraneSlovaPoS = self.con.getElementById("poS");
        vybraneSlovaPoS.addEventListener("click", poS);
        vybraneSlovaPoV = self.con.getElementById("poV");
        vybraneSlovaPoV.addEventListener("click", poV);
        vybraneSlovaPoZ = self.con.getElementById("poZ");
        vybraneSlovaPoZ.addEventListener("click", poZ);  
        vybraneSlovaPoL = self.con.getElementById("poL");
        vybraneSlovaPoL.addEventListener("click", poL);       
      }
      
      function poP() {
        self.con.innerHTML = '<p><button id="cv">Cvičenia</button> <button id="vybrane">Vybrané slová</button>   \
        <button id="help">Nápoveda</button> </p>  \
        <h2>Vybrané slová</h2> \
        <p><button id="poB">po B</button> <button id="poM">po M</button> <button id="poP">po P</button>  \
        <button id="poR">po R</button> <button id="poS">po S</button> <button id="poV">po V</button>  \
        <button id="poZ">po Z</button> <button id="poL">po L</button> \
        <p>pýcha, pýtať sa, pýr, kopyto, prepych, pysk (papuľa), pykať, pýšiť sa,   \
        pytliak, dopyt, zapýriť sa, pyré, pyžamo, pytač</p>   '
      
        cv = self.con.getElementById("cv");
        cv.addEventListener("click", zobrazCvicenia);
        help = self.con.getElementById("help");
        help.addEventListener("click", zobrazNapovedu);
        vybraneSlova = self.con.getElementById("vybrane");
        vybraneSlova.addEventListener("click", zobrazVybraneSlova);
        vybraneSlovaPoB = self.con.getElementById("poB");
        vybraneSlovaPoB.addEventListener("click", poB);
        vybraneSlovaPoM = self.con.getElementById("poM");
        vybraneSlovaPoM.addEventListener("click", poM);
        vybraneSlovaPoP = self.con.getElementById("poP");
        vybraneSlovaPoP.addEventListener("click", poP);
        vybraneSlovaPoR = self.con.getElementById("poR");
        vybraneSlovaPoR.addEventListener("click", poR);
        vybraneSlovaPoS = self.con.getElementById("poS");
        vybraneSlovaPoS.addEventListener("click", poS);
        vybraneSlovaPoV = self.con.getElementById("poV");
        vybraneSlovaPoV.addEventListener("click", poV);
        vybraneSlovaPoZ = self.con.getElementById("poZ");
        vybraneSlovaPoZ.addEventListener("click", poZ);  
        vybraneSlovaPoL = self.con.getElementById("poL");
        vybraneSlovaPoL.addEventListener("click", poL);       
      } 
      
      function poR() {
        self.con.innerHTML = '<p><button id="cv">Cvičenia</button> <button id="vybrane">Vybrané slová</button>   \
        <button id="help">Nápoveda</button> </p>  \
        <h2>Vybrané slová</h2> \
        <p><button id="poB">po B</button> <button id="poM">po M</button> <button id="poP">po P</button>  \
        <button id="poR">po R</button> <button id="poS">po S</button> <button id="poV">po V</button>  \
        <button id="poZ">po Z</button> <button id="poL">po L</button> \
        <p>ryba, rýchly, ryť, rýpať, hrýzť, kryť, skryť, koryto, korytnačka, strýc, ryčať, ryža, bryndza, rys,  \
        rysovať, Korytnica, rýdzi, rýdzik, brýzgať, rytier, trýzniť, rým, ryha, kryha, poryv, úryvok, Torysa,     \
        ryšavý, prýštiť, trysk, kryštál, rýľ, rytmus</p>   '
      
        cv = self.con.getElementById("cv");
        cv.addEventListener("click", zobrazCvicenia);
        help = self.con.getElementById("help");
        help.addEventListener("click", zobrazNapovedu);
        vybraneSlova = self.con.getElementById("vybrane");
        vybraneSlova.addEventListener("click", zobrazVybraneSlova);
        vybraneSlovaPoB = self.con.getElementById("poB");
        vybraneSlovaPoB.addEventListener("click", poB);
        vybraneSlovaPoM = self.con.getElementById("poM");
        vybraneSlovaPoM.addEventListener("click", poM);
        vybraneSlovaPoP = self.con.getElementById("poP");
        vybraneSlovaPoP.addEventListener("click", poP);
        vybraneSlovaPoR = self.con.getElementById("poR");
        vybraneSlovaPoR.addEventListener("click", poR);
        vybraneSlovaPoS = self.con.getElementById("poS");
        vybraneSlovaPoS.addEventListener("click", poS);
        vybraneSlovaPoV = self.con.getElementById("poV");
        vybraneSlovaPoV.addEventListener("click", poV);
        vybraneSlovaPoZ = self.con.getElementById("poZ");
        vybraneSlovaPoZ.addEventListener("click", poZ);  
        vybraneSlovaPoL = self.con.getElementById("poL");
        vybraneSlovaPoL.addEventListener("click", poL);       
      } 
      
      function poS() {
        self.con.innerHTML = '<p><button id="cv">Cvičenia</button> <button id="vybrane">Vybrané slová</button>   \
        <button id="help">Nápoveda</button> </p>  \
        <h2>Vybrané slová</h2> \
        <p><button id="poB">po B</button> <button id="poM">po M</button> <button id="poP">po P</button>  \
        <button id="poR">po R</button> <button id="poS">po S</button> <button id="poV">po V</button>  \
        <button id="poZ">po Z</button> <button id="poL">po L</button> \
        <p>syn, syr, sýty, sypať, syseľ, syčať, sýkorka, sychravý, vysychať, osýpky, sypký, sykať</p>   '
      
        cv = self.con.getElementById("cv");
        cv.addEventListener("click", zobrazCvicenia);
        help = self.con.getElementById("help");
        help.addEventListener("click", zobrazNapovedu);
        vybraneSlova = self.con.getElementById("vybrane");
        vybraneSlova.addEventListener("click", zobrazVybraneSlova);
        vybraneSlovaPoB = self.con.getElementById("poB");
        vybraneSlovaPoB.addEventListener("click", poB);
        vybraneSlovaPoM = self.con.getElementById("poM");
        vybraneSlovaPoM.addEventListener("click", poM);
        vybraneSlovaPoP = self.con.getElementById("poP");
        vybraneSlovaPoP.addEventListener("click", poP);
        vybraneSlovaPoR = self.con.getElementById("poR");
        vybraneSlovaPoR.addEventListener("click", poR);
        vybraneSlovaPoS = self.con.getElementById("poS");
        vybraneSlovaPoS.addEventListener("click", poS);
        vybraneSlovaPoV = self.con.getElementById("poV");
        vybraneSlovaPoV.addEventListener("click", poV);
        vybraneSlovaPoZ = self.con.getElementById("poZ");
        vybraneSlovaPoZ.addEventListener("click", poZ);  
        vybraneSlovaPoL = self.con.getElementById("poL");
        vybraneSlovaPoL.addEventListener("click", poL);       
      }
      
      function poV() {
        self.con.innerHTML = '<p><button id="cv">Cvičenia</button> <button id="vybrane">Vybrané slová</button>   \
        <button id="help">Nápoveda</button> </p>  \
        <h2>Vybrané slová</h2> \
        <p><button id="poB">po B</button> <button id="poM">po M</button> <button id="poP">po P</button>  \
        <button id="poR">po R</button> <button id="poS">po S</button> <button id="poV">po V</button>  \
        <button id="poZ">po Z</button> <button id="poL">po L</button> \
        <p>vysoký, zvyk, vy, vykať, výr (sova), výskať, vyť (vlk vyje), vy (predpona), vyžla,     \
        vydra, vyhňa, výsosť, zvyšok, výskyt, výživa, výťah, vyučovanie, výpočet, výraz, vyrážka, výskum, výstava</p>   '
      
        cv = self.con.getElementById("cv");
        cv.addEventListener("click", zobrazCvicenia);
        help = self.con.getElementById("help");
        help.addEventListener("click", zobrazNapovedu);
        vybraneSlova = self.con.getElementById("vybrane");
        vybraneSlova.addEventListener("click", zobrazVybraneSlova);
        vybraneSlovaPoB = self.con.getElementById("poB");
        vybraneSlovaPoB.addEventListener("click", poB);
        vybraneSlovaPoM = self.con.getElementById("poM");
        vybraneSlovaPoM.addEventListener("click", poM);
        vybraneSlovaPoP = self.con.getElementById("poP");
        vybraneSlovaPoP.addEventListener("click", poP);
        vybraneSlovaPoR = self.con.getElementById("poR");
        vybraneSlovaPoR.addEventListener("click", poR);
        vybraneSlovaPoS = self.con.getElementById("poS");
        vybraneSlovaPoS.addEventListener("click", poS);
        vybraneSlovaPoV = self.con.getElementById("poV");
        vybraneSlovaPoV.addEventListener("click", poV);
        vybraneSlovaPoZ = self.con.getElementById("poZ");
        vybraneSlovaPoZ.addEventListener("click", poZ);  
        vybraneSlovaPoL = self.con.getElementById("poL");
        vybraneSlovaPoL.addEventListener("click", poL);       
      } 
      
      function poZ() {
        self.con.innerHTML = '<p><button id="cv">Cvičenia</button> <button id="vybrane">Vybrané slová</button>   \
        <button id="help">Nápoveda</button> </p>  \
        <h2>Vybrané slová</h2> \
        <p><button id="poB">po B</button> <button id="poM">po M</button> <button id="poP">po P</button>  \
        <button id="poR">po R</button> <button id="poS">po S</button> <button id="poV">po V</button>  \
        <button id="poZ">po Z</button> <button id="poL">po L</button> \
        <p>jazyk, nazývať sa, ozývať, prezývať, vyzývať, pozývať, vzývať</p>   '
      
        cv = self.con.getElementById("cv");
        cv.addEventListener("click", zobrazCvicenia);
        help = self.con.getElementById("help");
        help.addEventListener("click", zobrazNapovedu);
        vybraneSlova = self.con.getElementById("vybrane");
        vybraneSlova.addEventListener("click", zobrazVybraneSlova);
        vybraneSlovaPoB = self.con.getElementById("poB");
        vybraneSlovaPoB.addEventListener("click", poB);
        vybraneSlovaPoM = self.con.getElementById("poM");
        vybraneSlovaPoM.addEventListener("click", poM);
        vybraneSlovaPoP = self.con.getElementById("poP");
        vybraneSlovaPoP.addEventListener("click", poP);
        vybraneSlovaPoR = self.con.getElementById("poR");
        vybraneSlovaPoR.addEventListener("click", poR);
        vybraneSlovaPoS = self.con.getElementById("poS");
        vybraneSlovaPoS.addEventListener("click", poS);
        vybraneSlovaPoV = self.con.getElementById("poV");
        vybraneSlovaPoV.addEventListener("click", poV);
        vybraneSlovaPoZ = self.con.getElementById("poZ");
        vybraneSlovaPoZ.addEventListener("click", poZ);  
        vybraneSlovaPoL = self.con.getElementById("poL");
        vybraneSlovaPoL.addEventListener("click", poL);       
      }  
      
      function poL() {
        self.con.innerHTML = '<p><button id="cv">Cvičenia</button> <button id="vybrane">Vybrané slová</button>   \
        <button id="help">Nápoveda</button> </p>  \
        <h2>Výnimky po L</h2> \
        <p><button id="poB">po B</button> <button id="poM">po M</button> <button id="poP">po P</button>  \
        <button id="poR">po R</button> <button id="poS">po S</button> <button id="poV">po V</button>  \
        <button id="poZ">po Z</button> <button id="poL">po L</button> \
        <p>lyko, lysý, lýtko, lyžica, mlyn, plyn, plytký, slýchať, lyže, pomaly,   \
        plyš, blýskať sa, vzlykať, lýra, lyrika, lýceum, oplývať, plynúť, splývať, zlyhať</p>   '
      
        cv = self.con.getElementById("cv");
        cv.addEventListener("click", zobrazCvicenia);
        help = self.con.getElementById("help");
        help.addEventListener("click", zobrazNapovedu);
        vybraneSlova = self.con.getElementById("vybrane");
        vybraneSlova.addEventListener("click", zobrazVybraneSlova);
        vybraneSlovaPoB = self.con.getElementById("poB");
        vybraneSlovaPoB.addEventListener("click", poB);
        vybraneSlovaPoM = self.con.getElementById("poM");
        vybraneSlovaPoM.addEventListener("click", poM);
        vybraneSlovaPoP = self.con.getElementById("poP");
        vybraneSlovaPoP.addEventListener("click", poP);
        vybraneSlovaPoR = self.con.getElementById("poR");
        vybraneSlovaPoR.addEventListener("click", poR);
        vybraneSlovaPoS = self.con.getElementById("poS");
        vybraneSlovaPoS.addEventListener("click", poS);
        vybraneSlovaPoV = self.con.getElementById("poV");
        vybraneSlovaPoV.addEventListener("click", poV);
        vybraneSlovaPoZ = self.con.getElementById("poZ");
        vybraneSlovaPoZ.addEventListener("click", poZ);  
        vybraneSlovaPoL = self.con.getElementById("poL");
        vybraneSlovaPoL.addEventListener("click", poL);       
      } 
      
    }
    
    function zobrazNapovedu() {
      self.con.innerHTML = '<p><button id="cv">Cvičenia</button> <button id="vybrane">Vybrané slová</button>   \
      <button id="help">Nápoveda</button> </p>  \
      <h2>Nápoveda</h2> \
      <p>Cvičenia ti ponúkajú hravú formu učenia sa vybraných slov.<br> \
      <br>&nbsp&nbsp&nbspCvičenie 1 - vyber správne slovo z dvojice ponúknutých slov. \
      <br>&nbsp&nbsp&nbspCvičenie 2 - Medzi zobrazenými slovami vyber to, ktoré nie je vybrané. \
      <br>&nbsp&nbsp&nbspCvičenie 3 - zahraj sa pexeso, hľadaj dvojice slov.</p><br> \
      \
      <p>Pre zoznam vybraných slov stlač tlačidlo Vybrané slová a vyber si písmeno.</p>'
      
      cv = self.con.getElementById("cv");
      cv.addEventListener("click", zobrazCvicenia);
      help = self.con.getElementById("help");
      help.addEventListener("click", zobrazNapovedu);
      vybraneSlova = self.con.getElementById("vybrane");
      vybraneSlova.addEventListener("click", zobrazVybraneSlova);
    }
  
    
    this.Bclose.style.visibility = 'visible';
    this.Bclose.addEventListener ('mousedown', function (e) {
      self.hide ();
      menu.Add (self.ico);
      e.stopPropagation ();
    });


    this.ico = Asset.image ('obrazky/pen24.png');
    menu.Add (this.ico);
    this.ico.addEventListener ('mousedown', function (e) {
      self.show ();
      menu.Rem (self.ico);
      e.stopPropagation ();
    });  
  };

  (function (){
    function Tmp () {};
    Tmp.prototype = RWindow.prototype;
    okno.prototype = new Tmp ();
  })();
})();