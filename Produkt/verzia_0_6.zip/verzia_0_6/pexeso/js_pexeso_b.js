//by Peter
function zoznamVybranychSlov() {
	var b = '{"slova": [{"slovo": "by"}, {"slovo": "aby"}, {"slovo": "byľ"}, {"slovo": "bystrý"},{"slovo": "Bystrica"},{"slovo": "Bytča"},{"slovo": "byť"},{"slovo": "nábytok"},{"slovo": "nábytok"},{"slovo": "bývať"},{"slovo": "bydlisko"},{"slovo": "príbytok"},{"slovo": "dobytok"},{"slovo": "kobyla"},{"slovo": "obyčaj"},{"slovo": "býk"},{"slovo": "bylina"},{"slovo": "bydlo"},{"slovo": "dobyt"},{"slovo": "odbyt"},{"slovo": "byvol"},{"slovo": "bytost"},{"slovo": "bývalý"},{"slovo": "úbytok"},{"slovo": "prebytok"},{"slovo": "zbytočný"} ] }';
}

function zistiCiObrazok(path){
	var str = path;
    var pomString = str.substring(0,7);
	if (pomString === "obrazky"){
		var x = extrahujNazovObrazka(str);
		return x;
	}else{
		return str;
	}
}

function extrahujNazovObrazka(path){
	var str = path;
	var res = str.substring(str.indexOf("/")+1,str.indexOf("."));
    return res;
}


function jsonToArray(){
	var vybraneB = '{"slova": [{"slovo": "by"}, {"slovo": "aby"}, {"slovo": "byľ"}, {"slovo": "bystrý"},{"slovo": "Bystrica"},{"slovo": "Bytča"},{"slovo": "byť"},{"slovo": "nábytok"},{"slovo": "nábytok"},{"slovo": "bývať"},{"slovo": "bydlisko"},{"slovo": "príbytok"},{"slovo": "dobytok"},{"slovo": "kobyla"},{"slovo": "obyčaj"},{"slovo": "býk"},{"slovo": "bylina"},{"slovo": "bydlo"},{"slovo": "dobyt"},{"slovo": "odbyt"},{"slovo": "byvol"},{"slovo": "bytost"},{"slovo": "bývalý"},{"slovo": "úbytok"},{"slovo": "prebytok"},{"slovo": "zbytočný"} ] }';
	//var vybraneB = '{"slova": [{"slovo": "býk","url":"obrazky/býk.jpg"}]}';
	var jsonData = JSON.parse(vybraneB);

	var pocitadlo = 0;
	for (var i in jsonData){
			var pom = jsonData[i];	
	}

	pom.pexesoRandomPolicka();
	var array = [];
	for (var i = 0; i < 12; i++) {
	//for (var i= 0; i<pom.length; i++){
		array.push(pom[i].slovo);
		array.push(pom[i].slovo);
		//array.push(pom[i].url);
	}
	return array;	
}


var pexeso_hodnoty = [];
var pexeso_policka_id = [];
var policka_otocene = 0;

Array.prototype.pexesoRandomPolicka = function(){
    var i = this.length, j, temp;
    while(--i > 0){
        j = Math.floor(Math.random() * (i+1));
        temp = this[j];
        this[j] = this[i];
        this[i] = temp;
    }
}
function newBoard(){
	var policka_otocene = 0;
	var output = '';
	pexeso_pole = jsonToArray();
    pexeso_pole.pexesoRandomPolicka();

	for(var i = 0; i < pexeso_pole.length; i++){
		var pom = zistiCiObrazok(pexeso_pole[i]);
		
		output += '<div id="tile_'+i+'" onclick="pexesoOtocPolicko(this,\''+pom+'\')"></div>';	
	}	
	//output += '<div id="tile_2" onclick="pexesoOtocPolicko(this,\'byk\')"></div>';
	//output += '<div id="tile_3" onclick="pexesoOtocPolicko(this,\'byk\')"> <img src="obrazky/byk.jpg" height=60px, width=60px/> </div>';
	memory_board.innerHTML = output;
}

function pexesoOtocPolicko(policko,val){
	if(policko.innerHTML == "" && pexeso_hodnoty.length < 2){
		policko.style.background = 'url(obrazky/tile_bg1.png) no-repeat';
		policko.innerHTML = val;
		if(pexeso_hodnoty.length == 0){
			pexeso_hodnoty.push(val);
			pexeso_policka_id.push(policko.id);
		} else if(pexeso_hodnoty.length == 1){
			pexeso_hodnoty.push(val);
			pexeso_policka_id.push(policko.id);
			if(pexeso_hodnoty[0] == pexeso_hodnoty[1]){
				policka_otocene += 2;
				// Zmaze obe polia
				pexeso_hodnoty = [];
            	pexeso_policka_id = [];
				// Pozre ci cela hracia plocha bola otocena
				if(policka_otocene == pexeso_pole.length){
					alert("Skvelé vyhral si!!!");
					//alert("Skvelé vyhral si!!! ... Vytváram novú hru.");
					//memory_board.innerHTML = "";
					//newBoard();
				}
			} else {
				function otocNazad(){
				    // Otoci policko naspat
				    var tile_1 = document.getElementById(pexeso_policka_id[0]);
				    var tile_2 = document.getElementById(pexeso_policka_id[1]);
				    tile_1.style.background = 'url(obrazky/tile_bg0.png) no-repeat';
            	    tile_1.innerHTML = "";
				    tile_2.style.background = 'url(obrazky/tile_bg0.png) no-repeat';
					tile_2.innerHTML = "";
				    // Zmaze obe polia
				    pexeso_hodnoty = [];
            	    pexeso_policka_id = [];
				}
				setTimeout(otocNazad, 1000);
			}
		}
	}
}
newBoard();




