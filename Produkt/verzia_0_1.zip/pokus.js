


var okno;

(function () {

  okno = function () {
    RWindow.call (this, 100, 90, 200, 200, 'pen24.png');

    var self = this;

    this.change_cfg ({bgcolor:'rgb(164, 234, 164)', selcolor:'rgb(81, 218, 129)'});
    this.resizeable = true;
    this.dragable = true;
    this.lab.innerHTML = 'Vybrané slová';
    this.lab.style.textAlign = 'center';
    this.lab.style.marginLeft = '0px';
    
    this.con.innerHTML = '    <div id="container">  \
      <h1>Quiz o vybraných slovách</h1>     \
      <p>Za neodpovedané otázky body nedostaneš!!</p>    \
      <div id="content">        \
        <img src="" id="otazka" height="200" width="250">    \
        <div id="moznosti"></div>    \
        <p><button id="submit"></button></p>   \
        <p id="skore"></p>  \
        </div>    \
      </div>  '  
     



    this.Bclose.style.visibility = 'visible';
    this.Bclose.addEventListener ('mousedown', function (e) {
      self.hide ();
      menu.Add (self.ico);
      e.stopPropagation ();
    });


    this.ico = Asset.image ('obrazky/pen24.png');
    menu.Add (this.ico);
    this.ico.addEventListener ('mousedown', function (e) {
      self.show ();
      menu.Rem (self.ico);
      e.stopPropagation ();
    });
    
  };

  (function (){
    function Tmp () {};
    Tmp.prototype = RWindow.prototype;
    okno.prototype = new Tmp ();
  })();

})();